package com.example.pylearn.runner

import android.content.Context
import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object PythonRunner {
    private fun ensureStarted(context: Context) {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context))
        }
    }

    suspend fun runCode(context: Context, code: String, input: String): String {
        return withContext(Dispatchers.IO) {
            try {
                ensureStarted(context)
                val py = Python.getInstance()
                val module = py.getModule("sandbox_runner")
                module.callAttr("run_user_code", code, input).toString()
            } catch (e: PyException) {
                "❌ Python hata: ${e.message ?: "Bilinmeyen hata"}"
            } catch (e: Exception) {
                "❌ Çalıştırma hata: ${e.message ?: "Bilinmeyen hata"}"
            }
        }
    }
}
