package com.example.pylearn.model

data class Lesson(
    val id: String,
    val title: String,
    val body: String,
    val example: String,
)

data class TaskTest(
    val input: String,
    val output: String,
)

data class TaskItem(
    val id: String,
    val title: String,
    val desc: String,
    val starter: String,
    val tests: List<TaskTest>,
)

data class QuizQuestion(
    val id: String,
    val question: String,
    val choices: List<String>,
    val answerIndex: Int,
    val explain: String,
)

data class AppProgress(
    val doneLessons: Set<String> = emptySet(),
    val doneTasks: Set<String> = emptySet(),
    val xp: Int = 0,
    val level: Int = 1,
    val lastLessonId: String? = null,
    val lastTaskId: String? = null,
    val dailyGoalLessons: Int = 1,
    val dailyGoalTasks: Int = 1,
    val dailyDoneDate: String = "",
    val dailyDoneLessons: Int = 0,
    val dailyDoneTasks: Int = 0,
    val dailyRewardClaimed: String? = null,
    val quizDone: Int = 0,
    val quizBest: Int = 0,
)

data class RunnerUiState(
    val code: String = "print('Merhaba Dünya')",
    val input: String = "",
    val output: String = "",
    val isRunning: Boolean = false,
)
