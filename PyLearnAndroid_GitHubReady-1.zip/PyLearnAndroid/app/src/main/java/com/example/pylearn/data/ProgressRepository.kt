package com.example.pylearn.data

import android.content.Context
import com.example.pylearn.model.AppProgress
import org.json.JSONArray

class ProgressRepository(context: Context) {
    private val prefs = context.getSharedPreferences("pylearn_progress", Context.MODE_PRIVATE)

    fun load(): AppProgress {
        return AppProgress(
            doneLessons = readSet("done_lessons"),
            doneTasks = readSet("done_tasks"),
            xp = prefs.getInt("xp", 0),
            level = prefs.getInt("level", 1),
            lastLessonId = prefs.getString("last_lesson_id", null),
            lastTaskId = prefs.getString("last_task_id", null),
            dailyGoalLessons = prefs.getInt("daily_goal_lessons", 1),
            dailyGoalTasks = prefs.getInt("daily_goal_tasks", 1),
            dailyDoneDate = prefs.getString("daily_done_date", "") ?: "",
            dailyDoneLessons = prefs.getInt("daily_done_lessons", 0),
            dailyDoneTasks = prefs.getInt("daily_done_tasks", 0),
            dailyRewardClaimed = prefs.getString("daily_reward_claimed", null),
            quizDone = prefs.getInt("quiz_done", 0),
            quizBest = prefs.getInt("quiz_best", 0),
        )
    }

    fun save(progress: AppProgress) {
        prefs.edit()
            .putString("done_lessons", JSONArray(progress.doneLessons.toList()).toString())
            .putString("done_tasks", JSONArray(progress.doneTasks.toList()).toString())
            .putInt("xp", progress.xp)
            .putInt("level", progress.level)
            .putString("last_lesson_id", progress.lastLessonId)
            .putString("last_task_id", progress.lastTaskId)
            .putInt("daily_goal_lessons", progress.dailyGoalLessons)
            .putInt("daily_goal_tasks", progress.dailyGoalTasks)
            .putString("daily_done_date", progress.dailyDoneDate)
            .putInt("daily_done_lessons", progress.dailyDoneLessons)
            .putInt("daily_done_tasks", progress.dailyDoneTasks)
            .putString("daily_reward_claimed", progress.dailyRewardClaimed)
            .putInt("quiz_done", progress.quizDone)
            .putInt("quiz_best", progress.quizBest)
            .apply()
    }

    private fun readSet(key: String): Set<String> {
        val raw = prefs.getString(key, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return buildSet {
            for (i in 0 until arr.length()) add(arr.optString(i))
        }
    }
}
