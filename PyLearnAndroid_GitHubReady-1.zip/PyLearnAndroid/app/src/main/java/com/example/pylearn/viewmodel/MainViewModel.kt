package com.example.pylearn.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pylearn.data.ContentRepository
import com.example.pylearn.data.ProgressRepository
import com.example.pylearn.model.AppProgress
import com.example.pylearn.model.Lesson
import com.example.pylearn.model.QuizQuestion
import com.example.pylearn.model.RunnerUiState
import com.example.pylearn.model.TaskItem
import com.example.pylearn.runner.PythonRunner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val contentRepo = ContentRepository(app)
    private val progressRepo = ProgressRepository(app)

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _tasks = MutableStateFlow<List<TaskItem>>(emptyList())
    val tasks: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

    private val _quiz = MutableStateFlow<List<QuizQuestion>>(emptyList())
    val quiz: StateFlow<List<QuizQuestion>> = _quiz.asStateFlow()

    private val _progress = MutableStateFlow(AppProgress())
    val progress: StateFlow<AppProgress> = _progress.asStateFlow()

    private val _runner = MutableStateFlow(RunnerUiState())
    val runner: StateFlow<RunnerUiState> = _runner.asStateFlow()

    private val _taskMessages = MutableStateFlow<Map<String, String>>(emptyMap())
    val taskMessages: StateFlow<Map<String, String>> = _taskMessages.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _lessons.value = contentRepo.loadLessons()
            _tasks.value = contentRepo.loadTasks()
            _quiz.value = contentRepo.loadQuiz()
            _progress.value = ensureDailyReset(progressRepo.load())
            persist()
        }
    }

    fun lessonById(id: String): Lesson? = _lessons.value.firstOrNull { it.id == id }
    fun taskById(id: String): TaskItem? = _tasks.value.firstOrNull { it.id == id }

    fun openLesson(id: String) {
        val today = today()
        _progress.update { current ->
            val base = ensureDailyReset(current)
            val alreadyDone = id in base.doneLessons
            val updated = base.copy(
                doneLessons = base.doneLessons + id,
                lastLessonId = id,
                dailyDoneLessons = if (alreadyDone) base.dailyDoneLessons else base.dailyDoneLessons + 1,
            )
            applyDailyReward(updated, today)
        }
        persist()
    }

    fun openTask(id: String) {
        _progress.update { ensureDailyReset(it).copy(lastTaskId = id) }
        persist()
    }

    fun updateRunnerCode(value: String) {
        _runner.update { it.copy(code = value) }
    }

    fun updateRunnerInput(value: String) {
        _runner.update { it.copy(input = value) }
    }

    fun sendCodeToRunner(code: String) {
        _runner.update { it.copy(code = code) }
    }

    fun saveDailyGoal(lessons: Int, tasks: Int) {
        _progress.update {
            it.copy(
                dailyGoalLessons = lessons.coerceAtLeast(0),
                dailyGoalTasks = tasks.coerceAtLeast(0),
            )
        }
        persist()
    }

    fun resetDailyGoal() {
        _progress.update { it.copy(dailyGoalLessons = 1, dailyGoalTasks = 1) }
        persist()
    }

    fun runCode() {
        val code = _runner.value.code
        val input = _runner.value.input
        _runner.update { it.copy(isRunning = true, output = "Çalışıyor...") }

        viewModelScope.launch {
            val out = PythonRunner.runCode(getApplication(), code, input)
            _runner.update { it.copy(isRunning = false, output = out) }
        }
    }

    fun checkTask(taskId: String, code: String) {
        val task = taskById(taskId) ?: return
        openTask(taskId)
        _taskMessages.update { it + (taskId to "Test ediliyor...") }

        viewModelScope.launch {
            for ((index, test) in task.tests.withIndex()) {
                val got = PythonRunner.runCode(getApplication(), code, test.input).trim()
                val expected = test.output.trim()
                if (got != expected) {
                    _taskMessages.update {
                        it + (
                            taskId to "❌ Test ${index + 1} başarısız\n\nBeklenen:\n$expected\n\nGelen:\n$got"
                        )
                    }
                    return@launch
                }
            }

            _progress.update { current ->
                val base = ensureDailyReset(current)
                val alreadyDone = taskId in base.doneTasks
                var updated = base.copy(
                    doneTasks = base.doneTasks + taskId,
                    lastTaskId = taskId,
                    xp = if (alreadyDone) base.xp else base.xp + 10,
                    level = if (alreadyDone) base.level else ((base.xp + 10) / 100) + 1,
                    dailyDoneTasks = if (alreadyDone) base.dailyDoneTasks else base.dailyDoneTasks + 1,
                )
                updated = applyDailyReward(updated, today())
                updated
            }
            persist()
            _taskMessages.update { it + (taskId to "✅ Görev başarılı! (Kaydedildi +10 XP)") }
        }
    }

    fun continueLessonId(): String? = _progress.value.lastLessonId
    fun continueTaskId(): String? = _progress.value.lastTaskId

    fun progressText(): String {
        val p = _progress.value
        return "Seviye ${p.level}  •  XP ${p.xp}\nDers: ${p.doneLessons.size}/${_lessons.value.size}  •  Görev: ${p.doneTasks.size}/${_tasks.value.size}"
    }

    fun dailyText(): String {
        val p = ensureDailyReset(_progress.value)
        return "🎯 Bugün: Ders ${p.dailyDoneLessons}/${p.dailyGoalLessons}  •  Görev ${p.dailyDoneTasks}/${p.dailyGoalTasks}"
    }

    fun continueText(): String {
        val lessonTitle = _lessons.value.firstOrNull { it.id == _progress.value.lastLessonId }?.title
        val taskTitle = _tasks.value.firstOrNull { it.id == _progress.value.lastTaskId }?.title
        return when {
            lessonTitle != null && taskTitle != null -> "▶ Devam: Ders: $lessonTitle  •  Görev: $taskTitle"
            lessonTitle != null -> "▶ Devam: Ders: $lessonTitle"
            taskTitle != null -> "▶ Devam: Görev: $taskTitle"
            else -> "▶ Devam: (henüz bir şey açmadın)"
        }
    }

    fun tasksProgressText(): String {
        val total = _tasks.value.size
        val done = _progress.value.doneTasks.size
        val pct = if (total == 0) 0 else (done * 100) / total
        return "İlerleme: $done/$total (%$pct)"
    }

    private fun persist() {
        progressRepo.save(_progress.value)
    }

    private fun ensureDailyReset(progress: AppProgress): AppProgress {
        val today = today()
        return if (progress.dailyDoneDate == today) {
            progress
        } else {
            progress.copy(
                dailyDoneDate = today,
                dailyDoneLessons = 0,
                dailyDoneTasks = 0,
            )
        }
    }

    private fun applyDailyReward(progress: AppProgress, today: String): AppProgress {
        return if (
            progress.dailyDoneLessons >= progress.dailyGoalLessons &&
            progress.dailyDoneTasks >= progress.dailyGoalTasks &&
            progress.dailyRewardClaimed != today
        ) {
            val xp = progress.xp + 20
            progress.copy(
                xp = xp,
                level = (xp / 100) + 1,
                dailyRewardClaimed = today,
            )
        } else {
            progress
        }
    }

    private fun today(): String = LocalDate.now().toString()
}
