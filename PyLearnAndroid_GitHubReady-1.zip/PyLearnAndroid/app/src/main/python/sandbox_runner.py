# -*- coding: utf-8 -*-
import re
from typing import List

BANNED_PATTERNS = [
    r"\bimport\b",
    r"\bopen\s*\(",
    r"\beval\s*\(",
    r"\bexec\s*\(",
    r"\bcompile\s*\(",
    r"\b__import__\b",
    r"\bos\b",
    r"\bsys\b",
    r"\bsubprocess\b",
    r"\bpathlib\b",
    r"\bglobals\s*\(",
    r"\blocals\s*\(",
]


def _is_code_banned(code: str) -> bool:
    for pat in BANNED_PATTERNS:
        if re.search(pat, code, flags=re.IGNORECASE):
            return True
    return False


def run_user_code(code: str, user_input: str) -> str:
    if _is_code_banned(code):
        return "🚫 Güvenlik nedeniyle bu kod parçaları engellendi."

    output: List[str] = []
    inputs = user_input.splitlines()
    idx = 0

    def safe_print(*args, **kwargs):
        sep = kwargs.get("sep", " ")
        end = kwargs.get("end", "\n")
        output.append(sep.join(map(str, args)) + end)

    def safe_input(prompt: str = ""):
        nonlocal idx
        if idx < len(inputs):
            v = inputs[idx]
            idx += 1
            return v
        return ""

    safe_builtins = {
        "print": safe_print,
        "input": safe_input,
        "len": len,
        "range": range,
        "int": int,
        "float": float,
        "str": str,
        "bool": bool,
        "list": list,
        "dict": dict,
        "set": set,
        "tuple": tuple,
        "min": min,
        "max": max,
        "sum": sum,
        "enumerate": enumerate,
        "abs": abs,
        "round": round,
    }

    env = {"__builtins__": safe_builtins}

    try:
        exec(code, env, env)
        text = "".join(output).rstrip()
        return text if text else "✅ Çalıştı (çıktı yok)."
    except Exception as e:
        return f"❌ Hata: {type(e).__name__}: {e}"
