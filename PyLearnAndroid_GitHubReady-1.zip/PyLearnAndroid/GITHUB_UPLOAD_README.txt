1) GitHub reposunda mevcut PyLearnAndroid.zip dosyasini sil.
2) Bu paketi telefonda ac.
3) GitHub reposuna ZIP degil, bu klasorun ICINDEKI dosya ve klasorleri yukle:
   - app/
   - gradle/ (varsa)
   - .github/
   - build.gradle.kts
   - settings.gradle.kts
   - gradle.properties
   - README.md
4) Yukleme bitince repo icinde Actions sekmesine gir.
5) Build APK workflow'unu ac ve Run workflow bas.
6) Islem bitince Artifacts altindan APK indir.

Not: Bu paket GitHub Actions tarafinda APK derlemek icin hazirlandi.
